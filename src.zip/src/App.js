import {BrowserRouter, Routes, Route, data} from "react-router-dom"
import Home from "./pages/Home";
import Navbar from "./components/Navbar";
import StudentForm from "./components/StudentForm";
import { useState } from "react";
import StudentList from "./components/StudentList";
import StudentDetail from "./components/StudentDetail";
import axios from "axios";


const App = () => {
    
    axios
    .get("http://localhost:4000/etudiants")
    .then(res=>{
        const data = res.data
    })


    
    
    
    
    
    
    return ( 
        <BrowserRouter>
        
        
        <main>
            <Navbar/>
        <Routes>
            <Route path="/" element={<Home/>}/>
            <Route path="/add" element={<StudentForm etudiantsInitial={data}/>}/>
            <Route path="/students" element={<StudentList etudiantsInitial={data}/>}/>
            <Route path="/student/:id" element={<StudentDetail etudiantsInitial={data}/>}/>



        </Routes>
        </main>
        
        
        





        




        
        
        
        </BrowserRouter>
    );
}
 
export default App;